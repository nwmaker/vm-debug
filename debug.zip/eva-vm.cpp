/*
 * eva-vm.cpp
 *
 */
#include <iostream>

#include "src/Logger.h"
#include "src/vm/EvaVM.h"
#include "src/vm/EvaValue.h"

int main(int argc, char const *argv[]) {
  EvaVM vm;

  auto result = vm.exec(R"(
/*
  (def square (x) (* x x))
  (var square2 (lambda (x) (* x x)))
  (square2 3)
*/

//  (var x 10)
  (def foo () 10)
  (foo)

/*
    (var x 1)
    (var z 2)    
    (var y (+ x 1))
    (def square (x) (* x x))
    (begin
      (var a 10)
      (var b 20)
      (set a 100)
      (+ (square b) a))
*/
  )");

  //vm.dumpStack();

  std::cout << "\n";

  log(result);

  std::cout << "All done!\n";

  return 0;
}

