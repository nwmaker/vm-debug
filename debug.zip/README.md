# debugging vm

## before

All the example code in eva-vm.cpp is OK.

## after code optimization

There are just two changes as below:

* change 1 in EvaCompiler.h at line 273.
Comment this line in. Comment the two lines above out.

* change 2 in EvaVM.h at line 292.
Comment this line out. Comment the line below in.

Then all three example code has a runtime error of empty stack.

