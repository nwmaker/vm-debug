/**
 * Eva compiler.
 */

#ifndef __EvaCompiler_h
#define __EvaCompiler_h

#include <string>
#include <map>

#include "../disassembler/EvaDisassembler.h"
#include "../parser/EvaParser.h"
#include "../vm/EvaValue.h"
#include "../vm/Global.h"

#define ALLOC_CONST(tester, converter, allocator, value) \
  do {                                                   \
    for (auto i = 0; i < co->constants.size(); i++) {    \
      if (!tester(co->constants[i])) {                   \
        continue;                                        \
      }                                                  \
      if (converter(co->constants[i]) == value) {        \
        return i;                                        \
      }                                                  \
    }                                                    \
    co->constants.push_back(allocator(value));           \
  } while(false)

#define GEN_BINARY_OP(op) \
  do {                    \
    gen(exp.list[1]);     \
    gen(exp.list[2]);     \
    emit(op);             \
  } while(false)

#define FUNCTION_CALL(exp) \
  do {  \
    gen(exp.list[0]);  \
    for (auto i = 1; i < exp.list.size(); i++) { \
      gen(exp.list[i]);                          \
    }                                            \
    emit(OP_CALL);                               \
    emit(exp.list.size() - 1);                   \
  } while(false)

/**
 * Compiler class, emits bytecode, records constant pool, vars, etc.
 */
class EvaCompiler {
 public:
  EvaCompiler(std::shared_ptr<Global> global) :
    global(global), 
    disassembler(std::make_unique<EvaDisassembler>(global)) {}

  /**
   * Main compile API.
   */
  //CodeObject* compile(const Exp& exp) {
  void compile(const Exp& exp) {
    // allocate new code object
    //co = AS_CODE(ALLOC_CODE("main"));
    co = AS_CODE(createCodeObjectValue("main"));
    main = AS_FUNCTION(ALLOC_FUNCTION(co));

    // generate recursively from top-level
    gen(exp);

    // explicitly stopper
    emit(OP_HALT);

    // instead of return the codeObject
    // use the getter instead for compiler
    //return co;
  }

  /**
   * Main compile loop.
   */
  void gen(const Exp& exp) {
    // check the type from parser
    switch (exp.type) {
      /**
       * ----------------------------------------------
       * Numbers.
       */
      case ExpType::NUMBER:
        // const and index
        emit(OP_CONST);
        emit(numericConstIdx(exp.number));
        break;

      /**
       * ----------------------------------------------
       * Strings.
       */
      case ExpType::STRING:
        // const and index
        emit(OP_CONST);
        emit(stringConstIdx(exp.string));
        break;
      case ExpType::SYMBOL:
        // boolean is treated as symbol
        if (exp.string == "true" || exp.string == "false") {
          emit(OP_CONST);
          emit(booleanConstIdx(exp.string == "true" ? true : false));
        } else {
          // variables:
          auto varName = exp.string;
          // 1. local vars
          auto localIndex = co->getLocalIndex(varName);
          if (localIndex != -1) {
            emit(OP_GET_LOCAL);
            emit(localIndex);
          }
          else {
            // 2. global var
            if (!global->exists(varName)) {
              DIE << "[EvaCompiler]: Reference error: " << varName;
            }
            emit(OP_GET_GLOBAL);
            emit(global->getGlobalIndex(varName));
          }          
        }
        break;
      case ExpType::LIST:
        auto tag = exp.list[0];
        // special cases
        if (tag.type == ExpType::SYMBOL) {
          auto op = tag.string;
          
          //  binary math operations
          if (op == "+") {
            GEN_BINARY_OP(OP_ADD);
          }
          else if (op == "-") {
            GEN_BINARY_OP(OP_SUB);
          }
          else if (op == "*") {
            GEN_BINARY_OP(OP_MUL);
          }
          else if (op == "/") {
            GEN_BINARY_OP(OP_DIV);
          }
          // compare operations: (> 5 10)
          else if (compareOps_.count(op) != 0) {
            gen(exp.list[1]);
            gen(exp.list[2]);
            emit(OP_COMPARE);
            emit(compareOps_[op]);
          }
          // branch operation if
          // test consequence alternate
          else if (op == "if") {
            gen(exp.list[1]);
            // handle the false case, but where to jump?
            emit(OP_JMP_IF_FALSE);
            // else, init with 0 address, 2-byte address
            emit(0);
            emit(0);

            auto elseJmpAddr = getOffset() - 2;

            // handle true case, <consequent> part
            gen(exp.list[2]);
            emit(OP_JMP);
            // 2-byte address: 0 for now, just a place holder
            emit(0);
            emit(0);
            
            auto endAddr = getOffset() - 2;

            // patch the else branch
            auto elseBranchAddr = getOffset();
            patchJumpAddress(elseJmpAddr, elseBranchAddr);

            // emit <alternate> if we have it
            if (exp.list.size() == 4) {
              gen(exp.list[3]);
            }

            // patch the end
            auto endBranchAddr = getOffset();
            patchJumpAddress(endAddr, endBranchAddr);
          }
          // while loop
          else if (op == "while") {
            auto loopStartAddr = getOffset();
            // emit <test>
            gen(exp.list[1]);
            // loop end. init with 0 address, will be patched
            emit(OP_JMP_IF_FALSE);

            // two-byte address
            emit(0);
            emit(0);
            auto loopEndJmpAddr = getOffset() - 2;

            // emit <body>
            gen(exp.list[2]);
            // Goto loop start
            emit(OP_JMP);
            emit(0);
            emit(0);

            patchJumpAddress(getOffset() - 2, loopStartAddr);

            // patch the end
            auto loopEndAddr = getOffset() + 1;
            patchJumpAddress(loopEndJmpAddr, loopEndAddr);
          }
          // variabl declaration: (var x (+ y 10))
          //
          else if (op == "var") {
            auto varName = exp.list[1].string;
            // special treatment of (var foo (lambda ...))
            if (isLambda(exp.list[2])) {
              compileFunction(
                /* exp */ exp.list[2],
                /* name */ varName,
                /* params */ exp.list[2].list[1],
                /* body */ exp.list[2].list[2]); 
            } else {
              // initializer value
              gen(exp.list[2]);
            }

            // 1. global variables
            if (isGlobalScope()) {
              global->define(varName);

              emit(OP_SET_GLOBAL);
              emit(global->getGlobalIndex(varName));
            }
            // 2. local variables: optimize
            else {
              co->addLocal(varName); 
            }
          }
          // handle set to update the variable
          else if (op == "set") {
            auto varName = exp.list[1].string;
            // value
            gen(exp.list[2]);
            
            // 1. local vars
            auto localIndex = co->getLocalIndex(varName);
            if (localIndex != -1) {
              emit(OP_SET_LOCAL);
              emit(localIndex);
            }

            // 2. global vars
            else {
              auto globalIndex = global->getGlobalIndex(varName);
              if (globalIndex == -1) {
                DIE << "Reference error: " << varName << " is not defined.";
              }
              emit(OP_SET_GLOBAL);
              emit(globalIndex);
            }
          }
          // handle local variables and block
          else if (op == "begin") {
            scopeEnter();
            // compile each expression within the block
            for (auto i = 1; i < exp.list.size(); i++) {
              // the value of the last expression is kept
              // on the stack as the final result.
              bool isLast = i == exp.list.size()-1;
              // local variable or function (should not pop):
              //auto isLocalDecl = 
              //  isDeclaration(exp.list[i]) && !isGlobalScope();
              auto isLocalDecl = isDeclaration(exp.list[i]);

              // generate expression code
              gen(exp.list[i]);
              if (!isLast && !isLocalDecl) {
                emit(OP_POP);
              }
            }
            scopeExit();
          }
          // for lambda function
          // sugar for (var <name> (lambda <params> <body>))
          
          // function declaration:
          // (def <name> <params> <body>)
          // user defined function
          else if (op == "def") {
            // (def <name> <param> <body>)
            auto fnName = exp.list[1].string;

            // refactor the code
            compileFunction(
              /* exp */ exp,
              /* name */ fnName,
              /* params */ exp.list[2],
              /* body */ exp.list[3]);

            // define the function as a variable in our co
            if (isGlobalScope()) {
              global->define(fnName);
              emit(OP_SET_GLOBAL);
              emit(global->getGlobalIndex(fnName));
            } else {
              co->addLocal(fnName);
              // optimize
              // no need to explicitly set the var value
              // since the function is already on the stack at the needed slot
            } 
          }
          // lambda expression
          // (lambda (a b) (+ a b))
          else if (op == "lambda") {
            //
            compileFunction(exp, "lambda", exp.list[1], exp.list[2]); 
          }
          // native 
          // function calls
          // (square 2) -> change name to (native-square 3)
          else {
            // named function call
            FUNCTION_CALL(exp);
          }
        }
        // lambda function calls
        // ((lambda (x) (* x x)) 2)
        else {
          // inline lambda call
          FUNCTION_CALL(exp);
        }

        break;
    }
  }

  // disassemble all complication units
  void disassembleByteCode() {
    for (auto& co_ : codeObjects_) {
      disassembler->disassemble(co_);
    }
  }

  // return main function (entry point)
  FunctionObject* getMainFunction() { return main; }
 
private:
  // global object
  std::shared_ptr<Global> global;

  // add disassembler
  std::unique_ptr<EvaDisassembler> disassembler;

  // compile a function
  void compileFunction(const Exp& exp, const std::string fnName,
                       const Exp& params, const Exp& body) {
    // save previous code object
    auto prevCo = co;
    auto arity = params.list.size();

    // function code object
    auto coValue = createCodeObjectValue(fnName, arity);
    co = AS_CODE(coValue);
    // store new co as a constant:
    prevCo->constants.push_back(coValue);

    // function name is registered as a local
    // so the function can call itself recursively
    co->addLocal(fnName);

    // parameters are added as variables
    for (auto i = 0; i < arity; i++) {
      auto argName = params.list[i].string;
      co->addLocal(argName);
    }

    // compile body in the new code object
    gen(body);
    // if we don't have explicit block which pops locals,
    // we should pop arguments (if any) - callee cleanup.
    // +1 for the function itself which is set as a local.
    if (!isBlock(body)) {
      emit(OP_SCOPE_EXIT);
      emit(arity + 1);
    }
    // explicitly return to restore caller address
    emit(OP_RETURN);

    // create the function
    // simple functions are created at compile time
    auto fn = ALLOC_FUNCTION(co);
    // restore the code object
    co = prevCo;
    // add function as a constant to our co
    co->addConst(fn);
    emit(OP_CONST);
    emit(co->constants.size() - 1); 
  }
  
  // return main function (entry point)
  //FunctionObject* getMainFunction() { return main; }

  // create a new code object
  EvaValue createCodeObjectValue(const std::string& name, size_t arity = 0) {
    auto coValue = ALLOC_CODE(name, arity);
    auto co = AS_CODE(coValue);
    codeObjects_.push_back(co);
    return coValue;
  }

  // enter a new scope
  void scopeEnter() { co->scopeLevel++; }

  // exit a new scope
  void scopeExit() { 
    // pop vars from the stack if they were declared
    // within this specific scope
    auto varsCount = getVarsCountOnScopeExit();

    if (varsCount > 0 || co->arity > 0) {
      emit(OP_SCOPE_EXIT);

      // for functions do callee cleanup:
      // pop all arguments,
      // plus the function name
      if (isFunctionBody()) {
        varsCount += co->arity + 1;
      }
      emit(varsCount);
    }
    co->scopeLevel--; 
  }

  bool isGlobalScope() {
    return co->name == "main" && co->scopeLevel == 1;
  }

  bool isFunctionBody() {
    return co->name != "main" && co->scopeLevel == 1;
  }

  bool isDeclaration(const Exp& exp) { return isVarDeclaration(exp); }

  bool isBlock(const Exp& exp) {
    return isTaggedList(exp, "begin");
  }

  bool isVarDeclaration(const Exp& exp) { return isTaggedList(exp, "var"); }
  bool isLambda(const Exp& exp) { return isTaggedList(exp, "lambda"); }

  bool isTaggedList(const Exp& exp, const std::string& tag) {
    return exp.type == ExpType::LIST && exp.list[0].type == ExpType::SYMBOL &&
           exp.list[0].string == tag;
  }

  // pop the variables of the current scope
  // return number of vars used
  size_t getVarsCountOnScopeExit() {
    auto varsCount = 0;
    if (co->locals.size() > 0) {
      while (co->locals.back().scopeLevel == co->scopeLevel) {
        co->locals.pop_back();
        varsCount++;
      }
    }
    return varsCount;
  }

  // return current bytecode offset
  size_t getOffset() { return co->code.size(); }

  // allocate a numeric constant
  size_t numericConstIdx(double value) {
    ALLOC_CONST(IS_NUMBER, AS_NUMBER, NUMBER, value);
    return co->constants.size() - 1;
  }

  // allocate a string constant
  size_t stringConstIdx(const std::string& value) {
    ALLOC_CONST(IS_STRING, AS_CPPSTRING, ALLOC_STRING, value);
    return co->constants.size() - 1;
  }

  size_t booleanConstIdx(bool value) {
    ALLOC_CONST(IS_BOOLEAN, AS_BOOLEAN, BOOLEAN, value);
    return co->constants.size() - 1;
  }

  void emit(uint8_t code) { co->code.push_back(code); }

  void writeByteAtOffset(size_t offset, uint8_t value) {
    co->code[offset] = value;
  }

  //  
  void patchJumpAddress(size_t offset, uint16_t value) {
    //
    writeByteAtOffset(offset, (value >> 8) & 0xff);     
    writeByteAtOffset(offset + 1, value & 0xff);     
  }
  
  /**
   * Compiling code object.
   */
  CodeObject* co;

  /*
   * main entry point (function) 
   */
  FunctionObject* main;

  /*
   * all code objects, no static
   */
  std::vector<CodeObject*> codeObjects_;

  // compare ops map
  static std::map<std::string, uint8_t> compareOps_;

};

/**
 * Compare ops map.
 */
std::map<std::string, uint8_t> EvaCompiler::compareOps_ = {
    {"<", 0}, {">", 1}, {"==", 2}, {">=", 3}, {"<=", 4}, {"!=", 5},
};

#endif
