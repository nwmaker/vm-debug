/*
 * Eva virtual machine
 * 
 */
#ifndef __EvaVM_h__
#define __EvaVM_h__

#include <array>
#include <stack>
#include <string>
#include <vector>

#include "../Logger.h"
#include "../bytecode/OpCode.h"
#include "../compiler/EvaCompiler.h"
#include "../parser/EvaParser.h"
#include "EvaValue.h"
#include "Global.h"

// namespace fromm EvaParser.h generated file
using syntax::EvaParser;

#define READ_BYTE() *ip++

#define READ_SHORT() (ip += 2, (uint16_t)((ip[-2] << 8) | ip[-1]))

#define TO_ADDRESS(index) (&fn->co->code[index])

#define GET_CONST() (fn->co->constants[READ_BYTE()])

// stack top (stack overflow after exceeding
#define STACK_LIMIT 512

// the trick of using a blank do {} while(false)
// the order of op1 and op2 matters
// the order of pop() should be the reverse of push()
// this will cause a bug in substraction
//
#define BINARY_OP(op) \
  do { \
    auto op2 = AS_NUMBER(pop()); \
    auto op1 = AS_NUMBER(pop()); \
    push(NUMBER(op1 op op2)); \
  } while (false)

#define COMPARE_VALUES(op, v1, v2) \
  do {                             \
    bool res;                      \
    switch (op) {                  \
      case 0:                      \
        res = v1 < v2;             \
        break;                     \
      case 1:                      \
        res = v1 > v2;             \
        break;                     \
      case 2:                      \
        res = v1 == v2;            \
        break;                     \
      case 3:                      \
        res = v1 >= v2;            \
        break;                     \
      case 4:                      \
        res = v1 <= v2;            \
        break;                     \
      case 5:                      \
        res = v1 != v2;            \
        break;                     \
    }                              \
    push(BOOLEAN(res));            \
  } while(false)

/*
 * stack frame for function calls
 */
struct Frame {
  // return address of the caller (ip of the caller)
  uint8_t* ra;
  
  // base pointer of the caller
  EvaValue* bp;

  // reference to the running function:
  // contains code, locals, etc.
  FunctionObject* fn;
};

// global is shared in both VM and compiler 
// if the global is after parser, there is a warning
class EvaVM {
  public:
    EvaVM() 
      : global(std::make_shared<Global>()),
        parser(std::make_unique<EvaParser>()),
        compiler(std::make_unique<EvaCompiler>(global)) {
      setGlobalVariables();
    }

  /* push a value onto the stack 
   * instead of EvaValue value as input
   *
   */
  void push(const EvaValue& value) {
    // check against the stack limit
    if ((size_t)(sp - stack.begin()) == STACK_LIMIT) {
      DIE << "push(): Stack overflow.\n";
    }
    *sp = value;
    sp++;
  }

  /* pop a value from the stack */
  // can't be void
  EvaValue pop() {
    if (sp == stack.begin()) {
      DIE << "pop(): Empty stack.\n";
    }
    --sp;
    return *sp;
  }

  /*
   * peek a value from the stack
   * but do not remove it from the stack
   */
  EvaValue peek(size_t offset = 0) {
    if (stack.size() == 0) {
      DIE << "peek(): empty stack.\n";
    }
    return *(sp - 1 - offset);
  }

  /*
   * pops multiple values from the stack
   *
   */
  void popN(size_t count) {
    if (stack.size() == 0) {
      DIE << "popN: empty stack.\n";
    }
    sp -= count;
  }

  /* execute a program */
  // after introducing number, this should not be void
  EvaValue exec(const std::string &program) {
    // 1. parse the program
    //auto ast = parser->parse(program);
    // introduce the block starting with begin
    auto ast = parser->parse("(begin " + program + ")");

    // 2 compile ast to eve bytecode
    //co = compiler->compile(ast);
    // compiler does not return the codeObject, use the getter
    compiler->compile(ast);
    
    // start from the main entry point
    fn = compiler->getMainFunction();

    // this is important to get code initialized
    // before using it
    // add constant, but not use the value directly
    // we use a constant pool, so the code should just use the index
    // code = {OP_CONST, 42, OP_HALT};

    // add
    //constants.push_back(NUMBER(2)); 
    //constants.push_back(NUMBER(3)); 
    //code = {OP_CONST, 0, OP_CONST, 1, OP_ADD, OP_HALT};

    // sub
    //constants.push_back(NUMBER(10)); 
    //constants.push_back(NUMBER(3)); 
    //code = {OP_CONST, 0, OP_CONST, 1, OP_SUB, OP_HALT};

    // more complex math: 20
    // (- (* 10 3) 10)
    //constants.push_back(NUMBER(10)); 
    //constants.push_back(NUMBER(3)); 
    //constants.push_back(NUMBER(10)); 
    //code = {OP_CONST, 0, OP_CONST, 1, OP_MUL, OP_CONST, 2, OP_SUB, OP_HALT};

    //constants.push_back(ALLOC_STRING("hello"));
    //code = {OP_CONST, 0, OP_HALT};

    //constants.push_back(ALLOC_STRING("hello, "));
    //constants.push_back(ALLOC_STRING("world!"));
    //code = {OP_CONST, 0, OP_CONST, 1, OP_ADD, OP_HALT};

    // set instruction pointer to the beginning:
    //ip = &co->code[0];
    ip = &fn->co->code[0];

    // important to initialize the stack
    // or a segment fault in runtime
    sp = &stack[0];

    // init the base pointer
    bp = sp;

    // debug disassembly
    compiler->disassembleByteCode();

    return eval();
  }

  // before adding the number
  // eval() returns nothing, so void
  // after introducing the number, 
  /// eval() should return EvaValue type
  EvaValue eval() {
    for(;;) {
      //dumpStack();
      auto opcode = READ_BYTE();
      //log(opcode);
      switch(opcode) {
        case OP_HALT:
          // instead of return nothing
          return pop();
        case OP_CONST: {
          // after OP_CONST, need to read the index
          //auto constIndex = READ_BYTE();
          // get the actual value in the constant pool
          //auto constant = constants[constIndex];
          // push the value to the stack
          push(GET_CONST());
          break;
        }
        case OP_ADD: {
          auto op2 = pop();
          auto op1 = pop();
          if (IS_NUMBER(op1) && IS_NUMBER(op2)) {
            auto v1 = AS_NUMBER(op1);
            auto v2 = AS_NUMBER(op2);
            push(NUMBER(v1 + v2));
          }
          // string concatenation
          else if (IS_STRING(op1) && IS_STRING(op2)) {
            auto s1 = AS_CPPSTRING(op1);
            auto s2 = AS_CPPSTRING(op2);
            push(ALLOC_STRING(s1 + s2));
          }
          break;
          }
        case OP_SUB: {
          BINARY_OP(-);
          break;
        }
        case OP_MUL: {
          BINARY_OP(*);
          break;
        }
        case OP_DIV: {
          BINARY_OP(/);
          break;
        }
        case OP_COMPARE: {
          auto op = READ_BYTE();
          
          auto op2 = pop();
          auto op1 = pop();
          if (IS_NUMBER(op1) && IS_NUMBER(op2)) {
            auto v1 = AS_NUMBER(op1);
            auto v2 = AS_NUMBER(op2);
            COMPARE_VALUES(op, v1, v2);
          } else if (IS_STRING(op1) && IS_STRING(op2)) {
            auto s1 = AS_CPPSTRING(op1);
            auto s2 = AS_CPPSTRING(op2);
            COMPARE_VALUES(op, s1, s2);
          }
          break;
        }
        case OP_JMP_IF_FALSE: {
          auto cond = AS_BOOLEAN(pop()); // TODO: TO_BOOLEAN
          auto address = READ_SHORT();
          if (!cond) {
            ip = TO_ADDRESS(address);
          }
          break;
        }
        case OP_JMP: {
          ip = TO_ADDRESS(READ_SHORT());
          break;
        }
        case OP_GET_GLOBAL: {
          auto globalIndex = READ_BYTE();
          push(global->get(globalIndex).value);
          break;
        }
        // set a global variable:
        case OP_SET_GLOBAL: {
          auto globalIndex = READ_BYTE(); 
          //auto value = peek(0);
          auto value = pop();
          global->set(globalIndex, value);
          break;
        }
        case OP_POP:
          pop();
          break;

        case OP_GET_LOCAL: {
          auto localIndex = READ_BYTE();
          if (localIndex < 0 || localIndex >= stack.size()) {
            DIE << "OP_GET_LOCAL: invalid variable index: " << (int)localIndex;
          }
          push(bp[localIndex]);
          break;
        }
        case OP_SET_LOCAL: {
          auto localIndex = READ_BYTE();
          auto value = peek(0);
          if (localIndex < 0 || localIndex >= stack.size()) {
            DIE << "OP_SET_LOCAL: invalid variable index: " << (int)localIndex;
          }
          bp[localIndex] = value;
          break;
        }
        // scope exit (clean up variables
        // Note: variables sit right below the result of a block
        // so we move the result below, which will be the new top
        // after popping the variables
        case OP_SCOPE_EXIT: {
          // how many vars to pop
          auto count = READ_BYTE();
          // move the result above the vars
          *(sp - 1 - count) = peek(0);
          // pop the vars
          popN(count);
          break;
        }
        // function calls
        case OP_CALL: {
          auto argsCount = READ_BYTE();
          auto fnValue = peek(argsCount);
          // 1. native fuction
          if (IS_NATIVE(fnValue)) {
            AS_NATIVE(fnValue)->function();
            auto result = pop();
            // pop args and function
            // all arguments plus function itself
            popN(argsCount + 1);
            // push result back on the top
            push(result);
            break;
          }
          // 2. user-defined function
          auto callee = AS_FUNCTION(fnValue);

          callStack.push(Frame{ip, bp, fn}); 

          // to access locals, etc
          fn = callee;

          // set the base pointer for the callee
          bp = sp - argsCount - 1;

          // jump to the function code
          ip = &callee->co->code[0];

          //callStack.push(Frame{ip, bp, fn}); 

          break;          
        }

        case OP_RETURN: {
          // restore the caller address
          auto callerFrame = callStack.top();
          
          // restore ip, bp, and fn for caller
          ip = callerFrame.ra;
          bp = callerFrame.bp;
          fn = callerFrame.fn;

          callStack.pop();
          break;
        }

        default:
          DIE << "unknown opcode: " << std::hex << (int)opcode;
      }
    }
  }

  // set up global variables and functions
  void setGlobalVariables() {
    //global->define('x');
    //global->set('x', NUMBER(10));

    // single quote is a char
    // double quote makes a string
    //global->addConst("x", 10);
    //global->addConst("y", 20);
    // the above is the hardcoded value for global vars

    // native functions
    global->addNativeFunction(
      "native-square",
      [&]() {
        auto x = AS_NUMBER(peek(0));
        push(NUMBER(x * x));
      },
      1); // number of parameter requred by the square function

    global->addNativeFunction(
      "native-sum",
      [&]() {
        auto v2 = AS_NUMBER(peek(0));
        auto v1 = AS_NUMBER(peek(1)); // 0 causes a bug in sum native-function
        push(NUMBER(v1 + v2));
      },
      2);    
 
    global->addConst("VERSION", 1);
  }

  // global object
  std::shared_ptr<Global> global;

  /**
   * parser instance
   */
  std::unique_ptr<EvaParser> parser;

  /*
   * compiler
   */
  std::unique_ptr<EvaCompiler> compiler;

  /* instruction pointer */
  uint8_t* ip;

  /* stack pointer */
  // this can't be uint8_t*
  EvaValue* sp;

  // base pointer
  EvaValue* bp;

  /* Operands stack */
  // instead of using C++ stack, in the VM, just uses array for performance
  std::array<EvaValue, STACK_LIMIT> stack;

  /* constant pool, move it to CodeObject for compiler */
  //std::vector<EvaValue> constants;

  /* byte code, move it to Codeobject for compiler instead of EvaVM */
  //std::vector<uint8_t> code;

  // separate stack for calls, keep return address
  std::stack<Frame> callStack;

  /* code object */
  //CodeObject* co;
  FunctionObject* fn;

  /*
   * Debug functions 
   */
  // dump current stack
  void dumpStack() {
    std::cout << "\n------- Stack -----------\n";
    if (sp == stack.begin()) {
      std::cout << "(empty)";
    }
    auto csp = sp - 1;
    while (csp >= stack.begin()) {
      std::cout << *csp-- << "\n";
    }
    std::cout << "\n";
  }
};

#endif

