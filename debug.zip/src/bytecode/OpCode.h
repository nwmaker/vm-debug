/*
 * instruction set for Eva VM
 * bytecode
 *
 */

#ifndef __OpCode_h__
#define __OpCode_h__

// stop the program
#define OP_HALT 0x00

// push a const onto the stack
#define OP_CONST 0x01

// math instructions
#define OP_ADD 0x02
#define OP_SUB 0x03
#define OP_MUL 0x04
#define OP_DIV 0x05

// after compiler, then after boolean
#define OP_COMPARE 0x06

// branch operator, if
#define OP_JMP_IF_FALSE 0x07
#define OP_JMP 0x08

// global var
#define OP_GET_GLOBAL 0x09
#define OP_SET_GLOBAL 0x10

// block and local variables
// pop a value from the stack
#define OP_POP 0x11

// local variables
#define OP_GET_LOCAL 0x12
#define OP_SET_LOCAL 0x13
#define OP_SCOPE_EXIT 0x14

// native function
#define OP_CALL 0x15

// return from a function
// user defined function
#define OP_RETURN 0x16

#define OP_STR(op) \
  case OP_##op:    \
    return #op

std::string opcodeToString(uint8_t opcode) {
  switch(opcode) {
    OP_STR(HALT);
    OP_STR(CONST);
    OP_STR(ADD);
    OP_STR(SUB);
    OP_STR(MUL);
    OP_STR(DIV);
    OP_STR(COMPARE);
    OP_STR(JMP_IF_FALSE); 
    OP_STR(JMP);
    OP_STR(GET_GLOBAL);
    OP_STR(SET_GLOBAL);
    OP_STR(POP);
    OP_STR(GET_LOCAL);
    OP_STR(SET_LOCAL);
    OP_STR(SCOPE_EXIT);
    OP_STR(CALL);
    OP_STR(RETURN);
    default:
      DIE << "opcodeToString: unknown opcode: " << std::hex << (int)opcode; 
  }

  return "HALT"; // not reachable
}

#endif

